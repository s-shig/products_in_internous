package jp.co.internous.action;

public interface Mp3Player {

	public abstract void play();
	public abstract void stop();
	public abstract void next();
	public abstract void back();	
}
